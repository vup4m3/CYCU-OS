
#define PCH_H

#include<vector>
#include<fstream>
#include<string>

#endif //PCH_H
